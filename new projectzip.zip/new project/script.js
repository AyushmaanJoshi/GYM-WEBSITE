function openForm1() {
  document.getElementById("myForm").style.display = "block";
}

function closeForm1() {
  document.getElementById("myForm").style.display = "none";
}


function openForm2() {
  document.getElementById("myForm").style.display = "block";
}

function closeForm2() {
  document.getElementById("myForm").style.display = "none";
}

function openForm3() {
  document.getElementById("myForm").style.display = "block";
}

function closeForm3() {
  document.getElementById("myForm").style.display = "none";
}


function openForm4() {
  document.getElementById("myForm").style.display = "block";
}

function closeForm4() {
  document.getElementById("myForm").style.display = "none";
}

